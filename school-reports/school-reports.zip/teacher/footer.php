<!-- /Add Stock -->
<!-- jQuery -->
<script src="../assets/js/jquery-3.7.1.min.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<!-- Feather Icon JS -->
<script src="../assets/js/feather.min.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<!-- Slimscroll JS -->
<script src="../assets/js/jquery.slimscroll.min.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<!-- Bootstrap Core JS -->
<script src="../assets/js/bootstrap.bundle.min.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<!-- ApexChart JS -->
<script src="../assets/plugins/apexchart/apexcharts.min.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<script src="../assets/plugins/apexchart/chart-data.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<!-- Chart JS -->
<script src="../assets/plugins/chartjs/chart.min.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<script src="../assets/plugins/chartjs/chart-data.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<!-- Daterangepikcer JS -->
<script src="../assets/js/moment.min.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<script src="../assets/plugins/daterangepicker/daterangepicker.js"
	type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<!-- Select2 JS -->
<script src="../assets/plugins/select2/js/select2.min.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<!-- Color Picker JS -->
<script src="../assets/plugins/%40simonwep/pickr/pickr.es5.min.js"
	type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<!-- Custom JS -->
<script src="../assets/js/theme-colorpicker.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<script src="../assets/js/script.js" type="baf560cacd13bfb28c23b3e3-text/javascript"></script>
<script src="../assets/js/rocket-loader.min.js" data-cf-settings="baf560cacd13bfb28c23b3e3-|49" defer></script>
<script defer
	src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
	integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
	data-cf-beacon='{"rayId":"95e6786a8eafa804","version":"2025.6.2","serverTiming":{"name":{"cfExtPri":true,"cfEdge":true,"cfOrigin":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"3ca157e612a14eccbb30cf6db6691c29","b":1}'
	crossorigin="anonymous"></script>
</body>











