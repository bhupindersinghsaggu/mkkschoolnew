 <div class="sidebar" id="sidebar">
     <div class="sidebar-logo active">
         <a href="../index.php" class="logo logo-normal">
             <h3>M.K.K. School</h3>
         </a>
         <a href="../index.php" class="logo logo-white">
             <h3>M.K.K. School</h3>
         </a>
         <a href="../index.php" class="logo-small">
             <h3>M.K.K. School</h3>
         </a>
         <a id="toggle_btn" href="javascript:void(0);">
             <i data-feather="chevrons-left" class="feather-16"></i>
         </a>
     </div>
     <div class="sidebar-inner slimscroll">
         <div id="sidebar-menu" class="sidebar-menu">
             <ul>
                 <li class="submenu-open">
                     <h6 class="submenu-hdr">Reports</h6>
                     <ul>
                         <li><a href="./dashboard.php"><i data-feather="box"></i><span>NoteBook Reports</span></a></li>
                         <li><a href="./teacher_docs.php"><i data-feather="box"></i><span>My Documents</span></a></li>
                         <li><a href="./change-password.php"><i data-feather="box"></i><span>Change Password</span></a></li>
                     </ul>
                 </li>
             </ul>
         </div>
     </div>
 </div>